====================================================
LevelUp - Real-Life RPG Admin Panel & Backend Setup
====================================================

STEP 1: UPLOAD TO FILE MANAGER
------------------------------
1. Open InfinityFree Control Panel -> File Manager.
2. Open your website directory (usually 'htdocs/').
3. Upload this ZIP file and click 'Extract' directly inside 'htdocs/'.

STEP 2: IMPORT DATABASE IN PHPMYADMIN
-------------------------------------
1. In InfinityFree Control Panel, go to 'MySQL Databases'.
2. Note your:
   - MySQL Hostname (e.g., sql105.infinityfree.com)
   - MySQL Username (e.g., epiz_12345678)
   - MySQL Password (your account password)
   - MySQL Database Name (e.g., epiz_12345678_levelup_rpg)
3. Click phpMyAdmin next to your database name.
4. Click on your database on the left sidebar.
5. Click 'Import' tab -> Choose 'levelup_rpg.sql' -> Click 'Go'.

STEP 3: CONFIGURE config/database.php
------------------------------------
1. In File Manager, open 'config/database.php'.
2. Replace the 4 credentials on lines 7-10 with your InfinityFree details:
   define('DB_HOST', 'sql105.infinityfree.com'); // Put your actual MySQL host
   define('DB_NAME', 'epiz_12345678_levelup_rpg'); // Put your database name
   define('DB_USER', 'epiz_12345678');            // Put your username
   define('DB_PASS', 'YOUR_INFINITYFREE_PASSWORD');

STEP 4: LOG IN TO ADMIN PANEL
-----------------------------
1. Visit in your browser: http://your-domain.infinityfreeapp.com/login.php
2. Default Admin Credentials:
   Email:    admin@levelup.com
   Password: admin123
3. (Optional) Change your password inside Settings -> Account Security.

All set! Your LevelUp Admin Panel and APIs are live.
