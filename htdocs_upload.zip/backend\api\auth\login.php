<?php
/**
 * Login Endpoint
 * POST: identifier (username or email), password
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

handleCors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJson(405, ['status' => 'error', 'message' => 'Method Not Allowed']);
}

$db = getDB();
$input = getJsonBody();

$identifier = trim($input['identifier'] ?? $input['username'] ?? $input['email'] ?? '');
$password = $input['password'] ?? '';

if (empty($identifier) || empty($password)) {
    sendJson(422, [
        'status' => 'error',
        'code' => 'MISSING_CREDENTIALS',
        'message' => 'Please enter both username/email and password.'
    ]);
}

// Find user by username or email
$stmt = $db->prepare("
    SELECT *
    FROM users
    WHERE (username = ? OR email = ?)
    LIMIT 1
");
$stmt->execute([$identifier, strtolower($identifier)]);
$user = $stmt->fetch();

if (!$user) {
    sendJson(401, [
        'status' => 'error',
        'code' => 'INVALID_CREDENTIALS',
        'message' => 'Invalid username or password.'
    ]);
}

if ((int)$user['is_active'] !== 1) {
    sendJson(403, [
        'status' => 'error',
        'code' => 'ACCOUNT_DISABLED',
        'message' => 'Your account has been disabled by an administrator.'
    ]);
}

// Verify password strictly with password_verify
$passwordValid = false;
if (!empty($user['password_hash']) && password_verify($password, $user['password_hash'])) {
    $passwordValid = true;
}

if (!$passwordValid) {
    sendJson(401, [
        'status' => 'error',
        'code' => 'INVALID_CREDENTIALS',
        'message' => 'Invalid username or password.'
    ]);
}

// Generate new 30-day session token
$token = bin2hex(random_bytes(32));
$expiresAt = date('Y-m-d H:i:s', strtotime('+30 days'));

$tokenStmt = $db->prepare("
    INSERT INTO user_tokens (user_id, token, expires_at)
    VALUES (?, ?, ?)
");
$tokenStmt->execute([$user['id'], $token, $expiresAt]);

// Fetch user settings
$sStmt = $db->prepare("SELECT * FROM user_settings WHERE user_id = ? LIMIT 1");
$sStmt->execute([$user['id']]);
$settings = $sStmt->fetch() ?: [
    'dark_mode' => 1,
    'sound_effects' => 1,
    'selected_alarm_song' => 'fanfare_victory',
];

$skills = json_decode($user['skills_json'] ?? '{}', true) ?: ['Strength' => 50, 'Knowledge' => 50, 'Discipline' => 50];
$role = (isset($user['role']) && strtolower($user['role']) === 'admin') ? 'admin' : ((strtolower($user['email'] ?? '') === 'admin@levelup.com') ? 'admin' : 'user');

sendJson(200, [
    'status' => 'success',
    'message' => 'Welcome back, ' . $user['username'] . '!',
    'token' => $token,
    'expires_at' => $expiresAt,
    'user' => [
        'id' => (int)$user['id'],
        'username' => $user['username'],
        'display_name' => $user['display_name'] ?: $user['username'],
        'email' => $user['email'],
        'role' => $role,
        'avatar_id' => $user['avatar_id'] ?: 'hero1',
        'profile_image_path' => $user['profile_image_path'],
        'level' => (int)$user['level'],
        'total_xp' => (int)$user['total_xp'],
        'gold' => (int)$user['gold'],
        'current_streak' => (int)$user['current_streak'],
        'best_streak' => (int)$user['best_streak'],
        'skills' => $skills,
        'show_on_leaderboard' => (int)$user['show_on_leaderboard'],
        'hydration_current_streak' => (int)$user['hydration_current_streak'],
        'hydration_best_streak' => (int)$user['hydration_best_streak'],
        'last_hydration_date' => $user['last_hydration_date'],
    ],
    'settings' => [
        'dark_mode' => (bool)$settings['dark_mode'],
        'sound_effects' => (bool)$settings['sound_effects'],
        'selected_alarm_song' => $settings['selected_alarm_song'] ?? 'fanfare_victory',
    ]
]);
